int carta_para_cod(const char *carta);

void indices_array(const char *cartas, int *resultado) ;

int menorMultiploDeQuatro(int valor) ;

int mesmo_valor(const char *cartas) ;

int compara(const void *a, const void *b);

int sequencia(const char *cartas);

int dupla_sequencia(const char *cartas);

char *carta_mais_alta(const char *cartas);